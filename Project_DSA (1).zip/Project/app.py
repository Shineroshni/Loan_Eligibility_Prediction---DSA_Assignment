from flask import Flask, render_template, request, jsonify # type: ignore
import pandas as pd # type: ignore
import joblib # type: ignore

app = Flask(__name__)

# Load your trained model
model = joblib.load('loan_default_model_v2.pkl')

# Expected feature columns in the model
model_features = [
    'person_age', 'person_income', 'person_emp_exp', 'loan_amnt', 'loan_int_rate',
    'loan_percent_income', 'cb_person_cred_hist_length', 'credit_score', 'person_gender_male',
    'person_home_ownership_OTHER', 'person_home_ownership_OWN', 'person_home_ownership_RENT',
    'loan_intent_EDUCATION', 'loan_intent_HOMEIMPROVEMENT', 'loan_intent_MEDICAL',
    'loan_intent_PERSONAL', 'loan_intent_VENTURE', 'previous_loan_defaults_on_file_Yes'
]

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predictPage')
def form():
    return render_template('predictPage.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        input_json = request.get_json(force=True)

        # Start building the input dictionary
        data = {
            'person_age': float(input_json['person_age']),
            'person_income': float(input_json['person_income']),
            'person_emp_exp': float(input_json['person_emp_exp']),
            'loan_amnt': float(input_json['loan_amnt']),
            'loan_int_rate': float(input_json['loan_int_rate']),
            'loan_percent_income': float(input_json['loan_percent_income']),
            'cb_person_cred_hist_length': float(input_json['cb_person_cred_hist_length']),
            'credit_score': float(input_json['credit_score']),
            'person_gender_male': int(input_json['person_gender_male']),
            'previous_loan_defaults_on_file_Yes': int(input_json['previous_loan_defaults_on_file_Yes'])
        }

        # One-hot encode home ownership
        home_val = input_json['person_home_ownership']
        for category in ['OTHER', 'OWN', 'RENT']:
            data[f'person_home_ownership_{category}'] = 1 if home_val == category else 0

        # One-hot encode loan intent
        intent_val = input_json['loan_intent']
        for category in ['EDUCATION', 'HOME IMPROVEMENT', 'MEDICAL', 'PERSONAL', 'VENTURE']:
            data[f'loan_intent_{category}'] = 1 if intent_val == category else 0

        # Convert to DataFrame and reorder columns
        input_df = pd.DataFrame([data])
        input_df = input_df.reindex(columns=model_features, fill_value=0)

        # Predict
        prediction = model.predict(input_df)[0]
        proba = model.predict_proba(input_df)[0]

        result = {
            "predicted_class": int(prediction),
            "predicted_label": "✅ Likely to Repay Loan" if prediction == 0 else "⚠️ High Risk of Default",
            "prediction_probability": {
                "Repay": round(float(proba[0]), 3),
                "Default": round(float(proba[1]), 3)
            },
            "repay_confidence_percent": round(float(proba[0]) * 100, 1)
        }

        return jsonify(result)

    except Exception as e:
        print("❌ Error during prediction:", e)
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
